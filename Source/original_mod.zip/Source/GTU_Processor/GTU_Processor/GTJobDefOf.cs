﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RimWorld;
using Verse;

namespace GTU_Processor
{   
    [DefOf]
    public static class JobDefOf
    {
        public static JobDef FillGTProcessor;

        public static JobDef EmptyGTProcessor;

    }
}
